#ifndef ARROWEDITMENU_H
#define ARROWEDITMENU_H

#include "editmenu.h"

class ArrowEditMenu : public EditMenu
{
    Q_OBJECT

public:
    explicit ArrowEditMenu(QWidget * parent = nullptr);
};

#endif // ARROWEDITMENU_H
