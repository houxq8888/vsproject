#ifndef CLIPBOARDHISTORYWINDOW_H
#define CLIPBOARDHISTORYWINDOW_H

#include <QWidget>

class ClipboardHistoryWindow : public QWidget
{
public:
    ClipboardHistoryWindow();
};

#endif // CLIPBOARDHISTORYWINDOW_H
