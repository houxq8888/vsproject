#include "clipboardhistorywindow.h"

ClipboardHistoryWindow::ClipboardHistoryWindow()
{

}
