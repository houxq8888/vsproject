#include "cef_app_other.h"

CefAppOther::CefAppOther()
{

}
